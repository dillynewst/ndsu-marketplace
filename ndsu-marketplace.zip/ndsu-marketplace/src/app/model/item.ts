export interface Item {
    itemId : number;
    itemName : string;
    itemType : string;
    itemDescription : string;
    itemPrice : number;
    itemSeller : string;
}